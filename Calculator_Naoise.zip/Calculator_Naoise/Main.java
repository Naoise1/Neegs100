import java.util.Scanner;

class CalculatorSwitch{

    //defining the variables
    static String again;
    static double firstNumber;
    static double secondNumber;
    static char chooseOperation;

    // method printing text on the console
    static void Messages(){
        System.out.println("You can enter 2 values and choose an operation. Please use comma for decimals. Operators are: ");
        System.out.println("+ addition");
        System.out.println("- subtraction ");
        System.out.println("* multiplication ");
        System.out.println("/ division ");
        System.out.println("# exponent - first value is the base, second value is the exponent ");
    }
    // user input for calculations
    static void Input(){
        try(Scanner scanner=new Scanner(System.in)){
            System.out.println("Enter first value: ");
            firstNumber=scanner.nextDouble();
            System.out.println("Enter second value: ");
            secondNumber=scanner.nextDouble();
            System.out.println("Enter an operator +, -, *, /, #: ");
            chooseOperation=scanner.next().charAt(0);
            Calculation();
            System.out.println( " If you want to do try again type Y");
            again = scanner.next();
            Again();

            // handling the exceptions and exiting
        }catch (Exception e){
            System.out.println("Please choose valid numbers and the valid operations");
            System.exit (0);
        }
    }
    // method again checks if user puts yes and then it starts the method input
    static void Again(){
        while(again.equals("Y")){
            Input();
        }
    }
    // method for executing the calculations
    static void Calculation(){

// switch statement checks the operation that you chose and activates a case according to operation

        switch(chooseOperation) {
            case '+':
                System.out.println("Result is: " +(firstNumber+secondNumber));
                break;
            case '-':
                System.out.println("Result is: " +(firstNumber-secondNumber));
                break;
            case '*':
                System.out.println("Result is: " +(firstNumber*secondNumber));
                break;
            case '/':
                if (secondNumber==0) {
                    System.out.println("Cannot divide by 0");
                }
                else
                    System.out.println("Result is: " +(firstNumber/secondNumber));
                break;
            case '#':
                System.out.println("Result is: " +(Math.pow(firstNumber,secondNumber)));
                break;

            // operator doesn't match any case (+, -, *, /, #)
            default:
                System.out.print("Error - please choose a valid operator");
                return;
        }


    }
// main method - calls the messages and input methods

    public static void main(String[] args) {
        Messages();
        Input();

    }
}